# List for naming checkboxes
checkBoxIDList = list("checkB45", 
                      "checkB50", 
                      "checkB62",
                      "checkB80",
                      "checkB100",
                      "checkPam30",
                      "checkPam40",
                      "checkPam70",
                      "checkPam120",
                      "checkPam250")

# List for naming gap costs for checkboxes
checkGapList = list("checkB45Gap", 
                    "checkB50Gap", 
                    "checkB62Gap",
                    "checkB80Gap",
                    "checkB100Gap",
                    "checkPam30Gap",
                    "checkPam40Gap",
                    "checkPam70Gap",
                    "checkPam120Gap",
                    "checkPam250Gap")

# List for naming extension costs for checkboxes
checkExtList = list("checkB45Ext", 
                    "checkB50Ext", 
                    "checkB62Ext",
                    "checkB80Ext",
                    "checkB100Ext",
                    "checkPam30Ext",
                    "checkPam40Ext",
                    "checkPam70Ext",
                    "checkPam120Ext",
                    "checkPam250Ext")

# Lists for managing gap and extension costs
checkGapVal = list()
checkExtVal = list()


